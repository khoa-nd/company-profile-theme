<?php 
/*
 Title: Documentation
 Setting: pkli_basic_options
 Tab: Help & Support
 Tab Order: 20
 */

?>

<a href="http://thoughtengineer.com/wordpress-linkedin-login-plugin/">Plugin Documentation</a><br/><br/>

<a href="http://thoughtengineer.com/wordpress-linkedin-login-plugin/">Request Support</a><br/><br/>

<a href="http://thoughtengineer.com/contact/">Building A Startup Platform? Hire Us</a>
